import React, {useState} from 'react';
export default function App(){
  const [form,setForm] = useState({username:'',password:''});
  async function login(){
    const res = await fetch((import.meta.env.VITE_API_URL || 'http://localhost:3000') + '/api/auth/login',{
      method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(form)
    });
    const data = await res.json();
    if(res.ok) alert('Login sukses: ' + data.user.name + ' (' + data.user.role + ')');
    else alert('Login gagal');
  }
  return (
    <div className='min-h-screen flex items-center justify-center p-6'>
      <div className='max-w-md w-full bg-white rounded shadow p-6'>
        <div className='flex items-center gap-4'>
          <img src='/logo-koperasi.svg' alt='logo' className='w-16 h-16' />
          <div>
            <h1 className='text-2xl font-bold brand'>Koperasi Gotong Royong</h1>
            <div className='text-sm text-slate-500'>Portal anggota & admin</div>
          </div>
        </div>
        <div className='mt-6'>
          <input className='w-full p-2 border rounded mb-2' placeholder='username' value={form.username} onChange={e=>setForm({...form,username:e.target.value})} />
          <input type='password' className='w-full p-2 border rounded mb-2' placeholder='password' value={form.password} onChange={e=>setForm({...form,password:e.target.value})} />
          <div className='flex gap-2'>
            <button className='px-4 py-2 bg-gradient-to-r from-green-600 to-blue-600 text-white rounded' onClick={login}>Login</button>
            <button className='px-4 py-2 border rounded' onClick={()=>setForm({username:'',password:''})}>Reset</button>
          </div>
          <div className='mt-3 text-sm text-slate-600'>Contoh akun: <strong>Admin/Admin</strong> atau <strong>siti/siti</strong></div>
        </div>
      </div>
    </div>
  )
}
