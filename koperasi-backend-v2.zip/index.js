const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcrypt');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const DB_FILE = path.join(__dirname, 'data.json');

if(!fs.existsSync(DB_FILE)){
  const salt = bcrypt.genSaltSync(10);
  const data = {
    users: [
      { id:1, username:'Admin', password: bcrypt.hashSync('Admin', salt), role:'admin', name:'Admin' },
      { id:2, username:'siti', password: bcrypt.hashSync('siti', salt), role:'anggota', name:'Siti Aminah' },
      { id:3, username:'budi', password: bcrypt.hashSync('budi', salt), role:'anggota', name:'Budi Santoso' }
    ],
    members: [
      { id:2, nama:'Siti Aminah', nik:'3170000000000001', alamat:'Batam', simpanan_pokok:100000, simpanan_wajib:50000 },
      { id:3, nama:'Budi Santoso', nik:'3170000000000002', alamat:'Batam', simpanan_pokok:100000, simpanan_wajib:50000 }
    ],
    loans: [
      { id:1, member_id:2, jumlah:1000000, tenor:12, bunga:1.5, created_at: new Date().toISOString() }
    ],
    payments: []
  };
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null,2));
}

function readDB(){ return JSON.parse(fs.readFileSync(DB_FILE)); }
function writeDB(d){ fs.writeFileSync(DB_FILE, JSON.stringify(d,null,2)); }

app.post('/api/auth/login', (req,res)=>{
  const { username, password } = req.body;
  const db = readDB();
  const user = db.users.find(u=>u.username===username);
  if(!user) return res.status(401).json({ error: 'Invalid credentials' });
  if(!bcrypt.compareSync(password, user.password)) return res.status(401).json({ error: 'Invalid credentials' });
  res.json({ user: { username: user.username, role: user.role, name: user.name, member_id: user.id } });
});

app.get('/api/members', (req,res)=>{
  const db = readDB();
  res.json(db.members);
});

app.post('/api/members/register', (req,res)=>{
  const db = readDB();
  const { nama, nik, alamat, simpanan_pokok, simpanan_wajib, username, password } = req.body;
  const newId = db.members.length ? Math.max(...db.members.map(m=>m.id))+1 : 1;
  db.members.push({ id:newId, nama, nik, alamat, simpanan_pokok: simpanan_pokok||0, simpanan_wajib:simpanan_wajib||0 });
  const salt = bcrypt.genSaltSync(10);
  const hash = bcrypt.hashSync(password||'password', salt);
  db.users.push({ id:newId, username, password: hash, role:'anggota', name:nama });
  writeDB(db);
  res.json({ ok:true, memberId:newId });
});

app.get('/api/loans', (req,res)=>{
  const db = readDB();
  const member_id = req.query.member_id;
  const rows = member_id ? db.loans.filter(l=>String(l.member_id)===String(member_id)) : db.loans;
  res.json(rows);
});

app.post('/api/loans', (req,res)=>{
  const db = readDB();
  const { member_id, jumlah, tenor, bunga } = req.body;
  const newId = db.loans.length ? Math.max(...db.loans.map(l=>l.id))+1 : 1;
  const rec = { id:newId, member_id, jumlah: Number(jumlah), tenor: Number(tenor), bunga: Number(bunga), created_at: new Date().toISOString() };
  db.loans.push(rec);
  writeDB(db);
  res.json({ ok:true, id:newId });
});

app.get('/api/export', (req,res)=>{
  const db = readDB();
  res.json(db);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=> console.log('Backend running on', PORT));
